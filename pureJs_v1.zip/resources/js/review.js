function reviewInit() {
    var myTable = $('table').DataTable({
        pagingType: 'full_numbers',
        pageLength: 10
    });
    $.ajax({
        url: 'resources/assets/reviewQueueData.json',
        type: 'get',
        dataType: 'json',
        error: function (data) {
            console.log(data);

        },
        success: function (data) {
            console.log(data);
            $.each(data, function (key, val) {
                const rowDataString = JSON.stringify(val);
                myTable.row.add(
                    [
                        `<a scope='row' onClick='rowClick(${rowDataString})' style='color: #0f56bc;font-weight:bold;'>${val.SHORTTITLE}</a>`,
                        val.TYPE,
                        val.REVIEWSTATUS,
                        val.DEADLINE,
                    ]
                ).draw(false);
            })
        }
    });
}

function rowClick(val) {
    jQuery.ajax({
        url: 'pages/review-form.html',
        dataType: 'html',
        success: function (data) {
            renderForm(data, val);
        },
        error: function (xhr, error) {
            alert('error. see console for details');
        }
    });
}
function renderForm(data, val) {
    const peerReviewerList = ['Rajesh', 'Preeti', 'Shri', 'Duncan', 'Duncan', 'Keith'];
    const sectionReviewerList = ['Rajashekjar', 'Preeti', 'Erica Garcia', 'Sargent Hanson'];
    const divisionReviewerList = ['Samanth', 'Preeti', 'Alice Huff', 'Helene Joyce'];
    let peerListTemplate = '';
    $('.review-queue').removeClass('col-md-12').addClass('col-md-7');
    $('.review-form').removeClass('hide').addClass('col-md-5');
    $('.review-form').html(data);
    $('#title').text(val.SHORTTITLE);
    $('#deadline').text(val.DEADLINE);
    $('#type').text(val.TYPE);
    $.each(peerReviewerList, function(k, v) {
        peerListTemplate+=`<li>
        <div class="d-flex align-items-center mr-5">
            <p class="mb-0">
            ${v}
            </p>
            <div class="ml-auto">
                <input type="checkbox" (click)="postNotification($event,item)" class="primary">
            </div>
        </div>
    </li>`
    });
    $('#peerList').html(peerListTemplate);
}