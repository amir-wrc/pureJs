validateLogin = () => {
    sessionStorage.setItem('isLoggedIn', true);
    window.location.href = '#/home';
};

logOut = () => {
    sessionStorage.setItem('isLoggedIn', false);
    window.location.href = '#/login';
};