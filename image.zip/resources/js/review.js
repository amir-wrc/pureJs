function reviewInit() {
    var myTable = $('table').DataTable({
        pagingType: 'full_numbers',
        pageLength: 10
    });
    $.ajax({
        url: 'resources/assets/reviewQueueData.json',
        type: 'get',
        dataType: 'json',
        error: function (data) {
            console.log(data);

        },
        success: function (data) {
            console.log(data);
            $.each(data, function (key, val) {
                const rowDataString = JSON.stringify(val);
                myTable.row.add(
                    [
                        `<a scope='row' onClick='rowClick(${rowDataString})' style='color: #0f56bc;font-weight:bold;'>${val.SHORTTITLE}</a>`,
                        val.TYPE,
                        val.REVIEWSTATUS,
                        val.DEADLINE,
                    ]
                ).draw();
            })
        }
    });
}

function onClick() {
 // this.showModal = true; // Show-Hide Modal Check
    $("#myModal").show();

  }

  function onClick1(reviewerFlag) {
      $('#myModal2').show();
    let peerListTemplate1 = '';
    let sectionListTemplate1 = '';
    let divisionListTemplate1 = '';
    const peerReviewerList = ['Rajesh', 'Preeti', 'Shri', 'Duncan', 'Duncan', 'Keith'];
    const sectionReviewerList = ['Rajashekjar', 'Preeti', 'Erica Garcia', 'Sargent Hanson'];
    const divisionReviewerList = ['Samanth', 'Preeti', 'Alice Huff', 'Helene Joyce'];
    showPeerReviewerModal = true; // Show-Hide Modal Check
    if (reviewerFlag == "Peer"){
        $.each(peerReviewerList, function(k4, v4) {
            console.log(v4);
            
            peerListTemplate1+=`<option value="${v4}" [disabled]="">
            ${v4}
          </option>`
        });
        $('#peerReviewer').html(peerListTemplate1);
    }else if (reviewerFlag == "Section"){
     
      $.each(sectionReviewerList, function(k5, v5) {
        sectionListTemplate1+=   `<option value="${v5}" [disabled]="">
       ${v5}
      </option>`
    });
    $('#sectionReviewer').html(sectionListTemplate1);
    }
    else if (reviewerFlag == "Division"){
        $.each(divisionReviewerList, function(k6, v6) {
            divisionListTemplate1+=   `<option value="${v6}" [disabled]="">
          
           ${v6}
          </option>`
        });
        $('#divisionReviewer').html(divisionListTemplate1);
    }


  }

  function onClick2(reviewerFlag) {
    $('#myModal3').show();
    if (reviewerFlag == "ClearPeer"){
      
    }
    else if (reviewerFlag == "ClearSection"){
        $('#clear-peer').text();
    }
    else if (reviewerFlag == "ClearDiv"){
        $('#clear-peer').text();
    }

  }




  //Bootstrap Modal Close event
  function hide() {
    $('#myModal').hide();
    $('#myModal2').hide();
    $('#myModal3').hide();
  }


  function savePeerReviewer(){
    this.clearanceReviewForm.peerReviewer = this.clearanceReviewForm.peerReviewer;
    console.log(this.clearanceReviewForm.peerReviewer)
    this.showPeerReviewerModal = false;
    this.showModal3 = false;
    this.showModal = false;
    this.peerReviewerFlag = false;
    this.sectionReviewerFlag = false;
    this.divisionReviewerFlag = false;
    this.CpeerReviewerFlag = false;
    this.CsectionReviewerFlag = false;
    this.CdivisionReviewerFlag = false;
  }

function postNotification(event,name){

  //  console.log(event.srcElement[1].checked);
  if(event.srcElement.checked == true){
    this.notifyService.callNotificationApi(name).subscribe(data => {
      console.log(data);
    });
  }
}

function rowClick(val) {
    jQuery.ajax({
        url: 'pages/review-form.html',
        dataType: 'html',
        success: function (data) {
            renderForm(data, val);
        },
        error: function (xhr, error) {
            alert('error. see console for details');
        }
    });
}
function renderForm(data, val) {
var showModal;
var showModal3;
var showPeerReviewerModal;
var peerReviewerFlag = false;
var sectionReviewerFlag = false;
var divisionReviewerFlag = false;
var CpeerReviewerFlag = false;
var CsectionReviewerFlag = false;
var CdivisionReviewerFlag = false;
var accepted;
   const clearanceReviewForm = {peerReviewer: [],
        sectionReviewer: [],
        divisionReviewer: [],
        clearancePeerReviewer: " ",
        clearanceSectionReviewer: "",
        clearanceDivisionReviewer: "",
        
        };

    let peerListTemplate = '';
    let sectionListTemplate = '';
    let divisionListTemplate = '';
    $('#clear-peer').text(clearanceReviewForm.clearancePeerReviewer);
    $('#clear-section').text(clearanceReviewForm.clearanceSectionReviewer);
    $('#clear-division').text(clearanceReviewForm.clearanceDivisionReviewer);
    $('.review-queue').removeClass('col-md-12').addClass('col-md-7');
    $('.review-form').removeClass('hide').addClass('col-md-5');
    $('.review-form').html(data);
    $('#title').text(val.SHORTTITLE);
    $('#deadline').text(val.DEADLINE);
    $('#type').text(val.TYPE);
    $.each(clearanceReviewForm.peerReviewer, function(k, v) {
        peerListTemplate+=` <li class="">
        <div class="d-flex align-items-center mr-5">
          <p class="mb-0">
            ${v}
          </p>
          <div class="ml-auto">
            <label class="switch "> <input type="checkbox" (click)="postNotification($event,${v})" class="primary"> <span class="slider round"></span> </label>
          </div>
        </div>

      </li>`
    });
    $('#peerList').html(peerListTemplate);
    
    $.each(clearanceReviewForm.sectionReviewer, function(k1, v1) {
        sectionListTemplate+=`<li class="">
        <div class="d-flex align-items-center mr-5">
          <p class="mb-0">
            ${v1}
          </p>
          <div class="ml-auto">
            <label class="switch "> <input type="checkbox" (click)="postNotification($event,${v1})" class="primary"> <span class="slider round"></span> </label>
          </div>
        </div>

      </li>`
    });
    $('#sectionList').html(sectionListTemplate);

    $.each(clearanceReviewForm.divisionReviewer, function(k2, v2) {
        divisionListTemplate+=`<li class="">
        <div class="d-flex align-items-center mr-5">
          <p class="mb-0">
            ${v2}
          </p>
          <div class="ml-auto">
            <label class="switch "> <input type="checkbox" checked (click)="postNotification($event,${v2})" class="primary"> <span class="slider round"></span> </label>
          </div>
        </div>

      </li>`
    });
    $('#divisionList').html(divisionListTemplate);
}