$(document).ready(function () {
    $(window).on('hashchange', function () {
        console.log(window.location.hash);
        let data = sessionStorage.getItem('isLoggedIn');
        if (window.location.hash === '#/login') {
            jQuery.ajax({
                url: 'pages/login.html',
                dataType: 'html',
                success: function (data) {
                    $('.content-body-wrapper').html(data);
                    $('.content-header-wrapper').html('');
                },
                error: function (xhr, error) {
                    console.log('error. see console for details');
                }
            });
        }
        if (data === 'true') {
            if (window.location.hash === '#/home') {
                jQuery.ajax({
                    url: 'pages/dashboard.html',
                    dataType: 'html',
                    success: function (data) {
                        $('.content-body-wrapper').html(data);
                        $('.content-header-wrapper').load('pages/header.html');
                        homeInit();
                    },
                    error: function (xhr, error) {
                        alert('error. see console for details');
                    }
                });
            } else if (window.location.hash === '#/todo') {
                jQuery.ajax({
                    url: 'pages/todo.html',
                    dataType: 'html',
                    success: function (data) {
                        $('.content-body-wrapper').html(data);
                        $('.content-header-wrapper').load('pages/header.html');
                        toDoInit();
                    },
                    error: function (xhr, error) {
                        alert('error. see console for details');
                    }
                });
            } else if (window.location.hash === '#/review') {
                jQuery.ajax({
                    url: 'pages/review.html',
                    dataType: 'html',
                    success: function (data) {
                        $('.content-body-wrapper').html(data);
                        $('.content-header-wrapper').load('pages/header.html');
                        jQuery.ajax({
                            url: 'pages/review-que.html',
                            dataType: 'html',
                            success: function (data2) {
                                $('.review-queue').html(data2);
                                reviewInit();
                            },
                            error: function (xhr, error) {
                                alert('error. see console for details');
                            }
                        });
                        
                    },
                    error: function (xhr, error) {
                        alert('error. see console for details');
                    }
                });
            }
        } else {
            window.location.href = '#/login';
        }
    });
    let data = sessionStorage.getItem('isLoggedIn');
    if (data === 'true') {
        window.location.href = window.location.hash;
    } else {
        window.location.href = '#/login';
    }
    window.dispatchEvent(new HashChangeEvent("hashchange"));

});
