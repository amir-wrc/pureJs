function reviewInit() {
  var myTable = $("table").DataTable({
    pagingType: "full_numbers",
    pageLength: 10
  });
  $.ajax({
    url: "resources/assets/reviewQueueData.json",
    type: "get",
    dataType: "json",
    error: function(data) {
      console.log(data);
    },
    success: function(data) {
      console.log(data);
      $.each(data, function(key, val) {
        const rowDataString = JSON.stringify(val);
        myTable.row
          .add([
            `<a scope='row' onClick='rowClick(${rowDataString})' style='color: #0f56bc;font-weight:bold;'>${val.SHORTTITLE}</a>`,
            val.TYPE,
            val.REVIEWSTATUS,
            `<td class="pr-0"><p class="d-inline-block" style="width: 80%;">${val.DEADLINE}</p><div class="color-box" style="background-color: #FFAB01;"></div></td>`
          ])
          .draw();
      });
    }
  });
}

function onClick() {
  // this.showModal = true; // Show-Hide Modal Check
  $("#myModal").show();
}

function onClick1(reviewerFlag) {
  $("#myModal2").show();

  let peerListTemplate1 = "";
  let sectionListTemplate1 = "";
  let divisionListTemplate1 = "";
  const peerReviewerList = [
    "Rajesh",
    "Preeti",
    "Shri",
    "Duncan",
    "Duncan",
    "Keith"
  ];
  const sectionReviewerList = [
    "Rajashekjar",
    "Preeti",
    "Erica Garcia",
    "Sargent Hanson"
  ];
  const divisionReviewerList = [
    "Samanth",
    "Preeti",
    "Alice Huff",
    "Helene Joyce"
  ];

  if (reviewerFlag == "Peer") {
    $("#peer-2").removeClass("hide");
    $("#sec-2").addClass("hide");
    $("#dev-2").addClass("hide");
    $("#peerReviewer option")
      .filter(function() {
        return (
          $("#peerReviewer")
            .value()
            .indexOf($(this).text()) > -1
        ); //Options text exists in array
      })
      .prop("selected", true);
    $.each(peerReviewerList, function(k4, v4) {
      console.log(v4);

      peerListTemplate1 += `<option value="${v4}" [disabled]="">
            ${v4}
          </option>`;
    });
    $("#peerReviewer").html(peerListTemplate1);
  } else if (reviewerFlag == "Section") {
    $("#peer-2").addClass("hide");
    $("#sec-2").removeClass("hide");
    $("#dev-2").addClass("hide");
    $("#sectionReviwer option")
      .filter(function() {
        return (
          $("#sectionReviwer")
            .value()
            .indexOf($(this).text()) > -1
        ); //Options text exists in array
      })
      .prop("selected", true);
    $.each(sectionReviewerList, function(k5, v5) {
      sectionListTemplate1 += `<option value="${v5}" [disabled]="">
       ${v5}
      </option>`;
    });
    $("#sectionReviwer").html(sectionListTemplate1);
  } else if (reviewerFlag == "Division") {
    $("#peer-2").addClass("hide");
    $("#sec-2").addClass("hide");
    $("#dev-2").removeClass("hide");
    $("#divisionReviewer option")
      .filter(function() {
        return (
          $("#divisionReviewer")
            .value()
            .indexOf($(this).text()) > -1
        ); //Options text exists in array
      })
      .prop("selected", true);
    $.each(divisionReviewerList, function(k6, v6) {
      divisionListTemplate1 += `<option value="${v6}" [disabled]="">
          
           ${v6}
          </option>`;
    });
    $("#divisionReviewer").html(divisionListTemplate1);
  }
}

function onClick2(reviewerFlag) {
  $("#myModal3").show();
  let peerListTemplate1 = "";
  let sectionListTemplate1 = "";
  let divisionListTemplate1 = "";
  const peerReviewerList = [
    "Rajesh",
    "Preeti",
    "Shri",
    "Duncan",
    "Duncan",
    "Keith"
  ];
  const sectionReviewerList = [
    "Rajashekjar",
    "Preeti",
    "Erica Garcia",
    "Sargent Hanson"
  ];
  const divisionReviewerList = [
    "Samanth",
    "Preeti",
    "Alice Huff",
    "Helene Joyce"
  ];
  if (reviewerFlag == "ClearPeer") {
    $("#peer-3").removeClass("hide");
    $("#sec-3").addClass("hide");
    $("#dev-3").addClass("hide");
    $("#peer-auth option")
      .filter(function() {
        return (
          $("#peer-auth")
            .value()
            .indexOf($(this).text()) > -1
        ); //Options text exists in array
      })
      .prop("selected", true);
    $.each(peerReviewerList, function(k4, v4) {
      console.log('dshfghff',v4);

      peerListTemplate1 += `<option value="${v4}" [disabled]="">
            ${v4}
          </option>`;
    });
    $("#peer-auth").html(peerListTemplate1);
  } else if (reviewerFlag == "ClearSection") {
    $("#peer-3").addClass("hide");
    $("#sec-3").removeClass("hide");
    $("#dev-3").addClass("hide");
    $("#sec-auth option")
      .filter(function() {
        return (
          $("#sec-auth")
            .value()
            .indexOf($(this).text()) > -1
        ); //Options text exists in array
      })
      .prop("selected", true);
    $.each(sectionReviewerList, function(k5, v5) {
      sectionListTemplate1 += `<option value="${v5}" [disabled]="">
       ${v5}
      </option>`;
    });
    $("#sec-auth").html(sectionListTemplate1);
  } else if (reviewerFlag == "ClearDiv") {
    $("#peer-3").addClass("hide");
    $("#sec-3").addClass("hide");
    $("#dev-3").removeClass("hide");
    $("#dev-auth option")
      .filter(function() {
        return (
          $("#dev-auth")
            .value()
            .indexOf($(this).text()) > -1
        ); //Options text exists in array
      })
      .prop("selected", true);
    $.each(divisionReviewerList, function(k6, v6) {
      divisionListTemplate1 += `<option value="${v6}" [disabled]="">
          
           ${v6}
          </option>`;
    });
    $("#dev-auth").html(divisionListTemplate1);
  }
}

//Bootstrap Modal Close event
function hide() {
  $("#myModal").hide();
  $("#myModal2").hide();
  $("#myModal3").hide();
}

function savePeerReviewer() {
  let peerListTemplate = "";
  let sectionListTemplate = "";
  let divisionListTemplate = "";
  $.each($("#peerReviewer").val(), function(k, v) {
    peerListTemplate += ` <li class="">
      <div class="d-flex align-items-center mr-5">
        <p class="mb-0">
          ${v}
        </p>
        <div class="ml-auto">
          <label class="switch "> <input type="checkbox" (click)="postNotification($event,${v})" class="primary"> <span class="slider round"></span> </label>
        </div>
      </div>

    </li>`;
  });
  $("#peerList").html(peerListTemplate);

  $.each($("#sectionReviwer").val(), function(k1, v1) {
    sectionListTemplate += `<li class="">
      <div class="d-flex align-items-center mr-5">
        <p class="mb-0">
          ${v1}
        </p>
        <div class="ml-auto">
          <label class="switch "> <input type="checkbox" (click)="postNotification($event,${v1})" class="primary"> <span class="slider round"></span> </label>
        </div>
      </div>

    </li>`;
  });
  $("#sectionList").html(sectionListTemplate);

  $.each($("#divisionReviewer").val(), function(k2, v2) {
    divisionListTemplate += `<li class="">
      <div class="d-flex align-items-center mr-5">
        <p class="mb-0">
          ${v2}
        </p>
        <div class="ml-auto">
          <label class="switch "> <input type="checkbox" checked (click)="postNotification($event,${v2})" class="primary"> <span class="slider round"></span> </label>
        </div>
      </div>

    </li>`;
  });
  $("#divisionList").html(divisionListTemplate);
  hide();

  /*     this.showPeerReviewerModal = false;
    this.showModal3 = false;
    this.showModal = false;
    this.peerReviewerFlag = false;
    this.sectionReviewerFlag = false;
    this.divisionReviewerFlag = false;
    this.CpeerReviewerFlag = false;
    this.CsectionReviewerFlag = false;
    this.CdivisionReviewerFlag = false; */
}
function addPeerReviewer() {
  let peerListTemplate = "";
  let sectionListTemplate = "";
  let divisionListTemplate = "";
  $.each($("#peer-auth").val(), function(k, v) {
    peerListTemplate += ` <li class="">
      <div class="d-flex align-items-center mr-5">
        <p class="mb-0">
          ${v}
        </p>
       
      </div>

    </li>`;
  });
  $("#clear-user").html(peerListTemplate);

  $.each($("#sec-auth").val(), function(k1, v1) {
    sectionListTemplate += `<li class="">
      <div class="d-flex align-items-center mr-5">
        <p class="mb-0">
          ${v1}
        </p>
        
      </div>

    </li>`;
  });
  $("#clear-section").html(sectionListTemplate);

  $.each($("#dev-auth").val(), function(k2, v2) {
    divisionListTemplate += `<li class="">
      <div class="d-flex align-items-center mr-5">
        <p class="mb-0">
          ${v2}
        </p>
     
      </div>

    </li>`;
  });
  $("#clear-division").html(divisionListTemplate);
  hide();

  /*     this.showPeerReviewerModal = false;
    this.showModal3 = false;
    this.showModal = false;
    this.peerReviewerFlag = false;
    this.sectionReviewerFlag = false;
    this.divisionReviewerFlag = false;
    this.CpeerReviewerFlag = false;
    this.CsectionReviewerFlag = false;
    this.CdivisionReviewerFlag = false; */
}

function postNotification(event, name) {
  //  console.log(event.srcElement[1].checked);
  if (event.srcElement.checked == true) {
    this.notifyService.callNotificationApi(name).subscribe(data => {
      console.log(data);
    });
  }
}

function rowClick(val) {
  jQuery.ajax({
    url: "pages/review-form.html",
    dataType: "html",
    success: function(data) {
      renderForm(data, val);
    },
    error: function(xhr, error) {
      alert("error. see console for details");
    }
  });
}
function renderForm(data, val) {
  var showModal;
  var showModal3;
  var showPeerReviewerModal;
  var peerReviewerFlag = false;
  var sectionReviewerFlag = false;
  var divisionReviewerFlag = false;
  var CpeerReviewerFlag = false;
  var CsectionReviewerFlag = false;
  var CdivisionReviewerFlag = false;
  var accepted;
  const clearanceReviewForm = {
    peerReviewer: [],
    sectionReviewer: [],
    divisionReviewer: [],
    clearancePeerReviewer: " ",
    clearanceSectionReviewer: "",
    clearanceDivisionReviewer: ""
  };

  $("#clear-peer").text(clearanceReviewForm.clearancePeerReviewer);
  $("#clear-section").text(clearanceReviewForm.clearanceSectionReviewer);
  $("#clear-division").text(clearanceReviewForm.clearanceDivisionReviewer);
  $(".review-queue")
    .removeClass("col-md-12")
    .addClass("col-md-7");
  $(".review-form")
    .removeClass("hide")
    .addClass("col-md-5");
  $(".review-form").html(data);
  $("#title").text(val.SHORTTITLE);
  $("#deadline").text(val.DEADLINE);
  $("#type").text(val.TYPE);
}
